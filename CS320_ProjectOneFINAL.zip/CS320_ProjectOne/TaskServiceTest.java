import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
    private TaskService service;
    private Task task;

    @BeforeEach
    void setUp() {
        service = new TaskService();
        task = new Task("T001", "Homework", "Finish CS 320 assignment");
        service.addTask(task);
    }

    @Test
    void testAddTask() {
        assertEquals(task, service.getTask("T001"));
    }

    @Test
    void testAddNullTask() {
        TaskService newService = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            newService.addTask(null);
        });
    }

    @Test
    void testDuplicateTaskIdNotAllowed() {
        Task task2 = new Task("T001", "Project", "Build project");

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task2);
        });
    }

    @Test
    void testDeleteTask() {
        service.deleteTask("T001");

        assertThrows(IllegalArgumentException.class, () -> {
            service.getTask("T001");
        });
    }

    @Test
    void testDeleteMissingTask() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("BADID");
        });
    }

    @Test
    void testUpdateTaskName() {
        service.updateName("T001", "New Homework");

        assertEquals("New Homework", service.getTask("T001").getName());
    }

    @Test
    void testUpdateTaskDescription() {
        service.updateDescription("T001", "Updated description");

        assertEquals("Updated description", service.getTask("T001").getDescription());
    }

    @Test
    void testUpdateNameForMissingTask() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateName("BADID", "New Name");
        });
    }

    @Test
    void testUpdateDescriptionForMissingTask() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateDescription("BADID", "New Description");
        });
    }

    @Test
    void testUpdateNameWithInvalidValue() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateName("T001", "");
        });
    }

    @Test
    void testUpdateDescriptionWithInvalidValue() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateDescription("T001", "");
        });
    }
}