

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
    private ContactService service;
    private Contact contact;

    @BeforeEach
    void setUp() {
        service = new ContactService();
        contact = new Contact("12345", "John", "Smith", "6155551234", "123 Main St");
        service.addContact(contact);
    }

    @Test
    void testAddContact() {
        assertEquals(1, service.getContacts().size());
        assertEquals("12345", service.getContacts().get(0).getContactId());
    }

    @Test
    void testAddNullContact() {
        ContactService newService = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            newService.addContact(null);
        });
    }

    @Test
    void testAddDuplicateContactId() {
        Contact contact2 = new Contact("12345", "Jane", "Doe", "6155555678", "456 Oak St");

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact2);
        });
    }

    @Test
    void testGetContact() {
        Contact foundContact = service.getContact("12345");
        assertEquals("John", foundContact.getFirstName());
    }

    @Test
    void testGetContactNotFound() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.getContact("99999");
        });
    }

    @Test
    void testDeleteContact() {
        service.deleteContact("12345");
        assertEquals(0, service.getContacts().size());
    }

    @Test
    void testDeleteContactNotFound() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("99999");
        });
    }

    @Test
    void testUpdateFirstName() {
        service.updateFirstName("12345", "James");
        assertEquals("James", service.getContact("12345").getFirstName());
    }

    @Test
    void testUpdateLastName() {
        service.updateLastName("12345", "Brown");
        assertEquals("Brown", service.getContact("12345").getLastName());
    }

    @Test
    void testUpdatePhone() {
        service.updatePhone("12345", "6155559999");
        assertEquals("6155559999", service.getContact("12345").getPhone());
    }

    @Test
    void testUpdateAddress() {
        service.updateAddress("12345", "456 Oak St");
        assertEquals("456 Oak St", service.getContact("12345").getAddress());
    }

    @Test
    void testUpdateFirstNameNotFound() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("99999", "James");
        });
    }

    @Test
    void testUpdateLastNameNotFound() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateLastName("99999", "Brown");
        });
    }

    @Test
    void testUpdatePhoneNotFound() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updatePhone("99999", "6155559999");
        });
    }

    @Test
    void testUpdateAddressNotFound() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateAddress("99999", "456 Oak St");
        });
    }
}