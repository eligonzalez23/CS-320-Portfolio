import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    void testTaskCreatedSuccessfully() {
        Task task = new Task("T001", "Homework", "Finish CS 320 work");

        assertEquals("T001", task.getTaskId());
        assertEquals("Homework", task.getName());
        assertEquals("Finish CS 320 work", task.getDescription());
    }

    @Test
    void testValidBoundaryValues() {
        assertDoesNotThrow(() -> {
            new Task(
                "1234567890",
                "12345678901234567890",
                "12345678901234567890123456789012345678901234567890"
            );
        });
    }

    @Test
    void testTaskIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Homework", "Finish CS 320 work");
        });
    }

    @Test
    void testTaskIdCannotBeEmpty() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("", "Homework", "Finish CS 320 work");
        });
    }

    @Test
    void testTaskIdCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Homework", "Finish CS 320 work");
        });
    }

    @Test
    void testNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T001", null, "Finish CS 320 work");
        });
    }

    @Test
    void testNameCannotBeEmpty() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T001", "", "Finish CS 320 work");
        });
    }

    @Test
    void testNameCannotBeLongerThanTwentyCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T001", "This name is way too long", "Finish CS 320 work");
        });
    }

    @Test
    void testDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T001", "Homework", null);
        });
    }

    @Test
    void testDescriptionCannotBeEmpty() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T001", "Homework", "");
        });
    }

    @Test
    void testDescriptionCannotBeLongerThanFiftyCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("T001", "Homework", "This description is longer than fifty characters and should fail");
        });
    }

    @Test
    void testNameCanBeUpdated() {
        Task task = new Task("T001", "Homework", "Finish CS 320 work");

        task.setName("New Name");

        assertEquals("New Name", task.getName());
    }

    @Test
    void testDescriptionCanBeUpdated() {
        Task task = new Task("T001", "Homework", "Finish CS 320 work");

        task.setDescription("New description");

        assertEquals("New description", task.getDescription());
    }

    @Test
    void testSetNameInvalid() {
        Task task = new Task("T001", "Homework", "Finish CS 320 work");

        assertThrows(IllegalArgumentException.class, () -> task.setName(null));
        assertThrows(IllegalArgumentException.class, () -> task.setName(""));
        assertThrows(IllegalArgumentException.class,
                () -> task.setName("This name is way too long"));
    }

    @Test
    void testSetDescriptionInvalid() {
        Task task = new Task("T001", "Homework", "Finish CS 320 work");

        assertThrows(IllegalArgumentException.class, () -> task.setDescription(null));
        assertThrows(IllegalArgumentException.class, () -> task.setDescription(""));
        assertThrows(IllegalArgumentException.class,
                () -> task.setDescription("This description is longer than fifty characters and should fail"));
    }
}