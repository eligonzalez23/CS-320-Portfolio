

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    void testContactCreatedSuccessfully() {
        Contact contact = new Contact("12345", "John", "Smith", "6155551234", "123 Main Street");

        assertEquals("12345", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("6155551234", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test
    void testValidBoundaryValues() {
        assertDoesNotThrow(() -> {
            new Contact("1234567890", "FirstName1", "LastName12", "6155551234", "123456789012345678901234567890");
        });
    }

    @Test
    void testContactIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "John", "Smith", "6155551234", "123 Main Street");
        });
    }

    @Test
    void testContactIdNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "John", "Smith", "6155551234", "123 Main Street");
        });
    }

    @Test
    void testContactIdEmpty() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("", "John", "Smith", "6155551234", "123 Main Street");
        });
    }

    @Test
    void testFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Christopher", "Smith", "6155551234", "123 Main Street");
        });
    }

    @Test
    void testFirstNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", null, "Smith", "6155551234", "123 Main Street");
        });
    }

    @Test
    void testFirstNameEmpty() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "", "Smith", "6155551234", "123 Main Street");
        });
    }

    @Test
    void testLastNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Washingtonnn", "6155551234", "123 Main Street");
        });
    }

    @Test
    void testLastNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", null, "6155551234", "123 Main Street");
        });
    }

    @Test
    void testLastNameEmpty() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "", "6155551234", "123 Main Street");
        });
    }

    @Test
    void testPhoneTooShort() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Smith", "12345", "123 Main Street");
        });
    }

    @Test
    void testPhoneTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Smith", "61555512345", "123 Main Street");
        });
    }

    @Test
    void testPhoneNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Smith", null, "123 Main Street");
        });
    }

    @Test
    void testPhoneMustBeDigits() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Smith", "61555abcde", "123 Main Street");
        });
    }

    @Test
    void testAddressTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Smith", "6155551234", "123 Main Street Apartment 12345");
        });
    }

    @Test
    void testAddressNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Smith", "6155551234", null);
        });
    }

    @Test
    void testAddressEmpty() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Smith", "6155551234", "");
        });
    }

    @Test
    void testSetFirstNameValid() {
        Contact contact = new Contact("12345", "John", "Smith", "6155551234", "123 Main Street");
        contact.setFirstName("James");
        assertEquals("James", contact.getFirstName());
    }

    @Test
    void testSetFirstNameInvalid() {
        Contact contact = new Contact("12345", "John", "Smith", "6155551234", "123 Main Street");

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName("");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName(null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName("Christopher");
        });
    }

    @Test
    void testSetLastNameValid() {
        Contact contact = new Contact("12345", "John", "Smith", "6155551234", "123 Main Street");
        contact.setLastName("Jones");
        assertEquals("Jones", contact.getLastName());
    }

    @Test
    void testSetLastNameInvalid() {
        Contact contact = new Contact("12345", "John", "Smith", "6155551234", "123 Main Street");

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName("");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName(null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName("Washingtonnn");
        });
    }

    @Test
    void testSetPhoneValid() {
        Contact contact = new Contact("12345", "John", "Smith", "6155551234", "123 Main Street");
        contact.setPhone("6155559999");
        assertEquals("6155559999", contact.getPhone());
    }

    @Test
    void testSetPhoneInvalid() {
        Contact contact = new Contact("12345", "John", "Smith", "6155551234", "123 Main Street");

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhone(null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhone("12345");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhone("615555abcd");
        });
    }

    @Test
    void testSetAddressValid() {
        Contact contact = new Contact("12345", "John", "Smith", "6155551234", "123 Main Street");
        contact.setAddress("456 Oak Street");
        assertEquals("456 Oak Street", contact.getAddress());
    }

    @Test
    void testSetAddressInvalid() {
        Contact contact = new Contact("12345", "John", "Smith", "6155551234", "123 Main Street");

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setAddress("");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setAddress(null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setAddress("123 Main Street Apartment 12345");
        });
    }
}