
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

public class AppointmentTest {

    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 86400000);
    }

    private Date pastDate() {
        return new Date(System.currentTimeMillis() - 86400000);
    }

    @Test
    public void testValidAppointment() {
        Appointment appointment =
                new Appointment("12345", futureDate(), "Doctor Visit");

        assertEquals("12345", appointment.getAppointmentId());
        assertEquals("Doctor Visit", appointment.getDescription());
    }

    @Test
    public void testNullAppointmentId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate(), "Doctor Visit");
        });
    }

    @Test
    public void testEmptyAppointmentId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("", futureDate(), "Doctor Visit");
        });
    }

    @Test
    public void testAppointmentIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate(), "Doctor Visit");
        });
    }

    @Test
    public void testNullDate() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", null, "Doctor Visit");
        });
    }

    @Test
    public void testPastDate() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", pastDate(), "Doctor Visit");
        });
    }

    @Test
    public void testNullDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate(), null);
        });
    }

    @Test
    public void testEmptyDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate(), "");
        });
    }

    @Test
    public void testDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(
                    "12345",
                    futureDate(),
                    "This description is definitely longer than fifty characters.");
        });
    }

    @Test
    public void testSetDescription() {
        Appointment appointment =
                new Appointment("12345", futureDate(), "Doctor Visit");

        appointment.setDescription("Dentist Visit");

        assertEquals("Dentist Visit", appointment.getDescription());
    }

    @Test
    public void testSetDescriptionInvalid() {
        Appointment appointment =
                new Appointment("12345", futureDate(), "Doctor Visit");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription("");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription(null);
        });
    }

    @Test
    public void testSetAppointmentDate() {
        Appointment appointment =
                new Appointment("12345", futureDate(), "Doctor Visit");

        Date newDate = new Date(System.currentTimeMillis() + 172800000);

        appointment.setAppointmentDate(newDate);

        assertEquals(newDate, appointment.getAppointmentDate());
    }

    @Test
    public void testSetAppointmentDateInvalid() {
        Appointment appointment =
                new Appointment("12345", futureDate(), "Doctor Visit");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDate(pastDate());
        });

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDate(null);
        });
    }
}