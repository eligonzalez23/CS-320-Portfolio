
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {
    private AppointmentService service;

    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 86400000);
    }

    @BeforeEach
    void setUp() {
        service = new AppointmentService();
        service.addAppointment("12345", futureDate(), "Doctor Visit");
    }

    @Test
    public void testAddAppointment() {
        Appointment appointment = service.getAppointment("12345");

        assertEquals("12345", appointment.getAppointmentId());
        assertEquals("Doctor Visit", appointment.getDescription());
    }

    @Test
    public void testDuplicateAppointmentId() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment("12345", futureDate(), "Dentist Visit");
        });
    }

    @Test
    public void testGetAppointment() {
        Appointment appointment = service.getAppointment("12345");

        assertEquals("12345", appointment.getAppointmentId());
    }

    @Test
    public void testGetAppointmentNotFound() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.getAppointment("99999");
        });
    }

    @Test
    public void testDeleteAppointment() {
        service.deleteAppointment("12345");

        assertThrows(IllegalArgumentException.class, () -> {
            service.getAppointment("12345");
        });
    }

    @Test
    public void testDeleteNonexistentAppointment() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("99999");
        });
    }
}